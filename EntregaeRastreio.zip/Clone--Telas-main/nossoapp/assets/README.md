Usamos o 
import { Ionicons } from '@expo/vector-icons';
https://ionic.io/ionicons

Para pegar os ícones dos elementos.