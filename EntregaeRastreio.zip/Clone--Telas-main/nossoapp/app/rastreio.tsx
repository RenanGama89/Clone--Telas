import React from 'react';
import { Ionicons } from '@expo/vector-icons';
import { router} from 'expo-router';
import { View, Text, StyleSheet, Image, Pressable } from 'react-native';

export default function Entrega(){
    return(
        <View style={styles.container}>
            <Pressable onPress={() => router.push('/(tabs)')}>
            <Ionicons name="chevron-back-outline" size={40} style={styles.icon}/>
            </Pressable>
            <Text style={styles.title}>Rastreio</Text>
            <Image
                    source={{ uri: 'https://cdn.pixabay.com/photo/2019/07/19/09/54/map-4348394_960_720.png' }}
                    style={styles.imagem}
                    resizeMode="contain"
                  />

            <View style={styles.row}>
            <Text style={styles.text}>Tempo Estimado</Text>
            <Text style={styles.value}>20:40</Text>
            </View>
            <View style={styles.card}>
                    <View style={styles.logo} />
                    <View style={styles.infoBlock}>
                      <Text style={styles.subtitle}>Nome do Entregador</Text>
                      <Text style={styles.text}>Veiculo: CG 160</Text>
                      <Text style={styles.text}>Placa: ETG5P89</Text>
                    </View>
                  </View>

            <View style={styles.linha} />

            <View style={styles.row}>
            <Text style={styles.text}>Total</Text>
            <Text style={styles.value}>R$ 45,00</Text>
            </View>

            <View style={styles.card}>
                    <Pressable style={styles.infoBlock} onPress={() => router.push('/pagamento')}>
                      <Text style={styles.title}>Pagar</Text>
                    </Pressable>
                  </View>
                  
        </View>
    );
}

const styles = StyleSheet.create({
     container: {
    flex: 1,
    backgroundColor: '#fff',
  },
    title:{
       textAlign: "center",
        fontSize: 45,
        fontFamily: "Arial"
    },
    subtitle:{
        fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 4,
    },

     imagem: {
    width: 600,
    height: 300,
    marginBottom: 5,
    alignSelf: 'center',
  },
  icon:{
    alignSelf: 'flex-start',
    marginTop: 0,
    marginBottom: 7,
    marginLeft: 10,
  },
  text:{
    marginLeft: 15,
    marginBottom: 7,
    textAlign:"left",
    fontSize: 15,
    fontFamily:'Arial',
    color: "#3c3c3c",
  },
  linha: {
  borderBottomColor: '#000',
  borderBottomWidth: 1,
  marginVertical: 15,
  marginHorizontal: 20,
},
  row: {
  flexDirection: 'row',
  justifyContent: 'space-between',
  marginHorizontal: 10,
  marginBottom: 7,
},
value: {
  fontSize: 15,
  fontFamily: 'Arial',
  color: '#3c3c3c',
},
  card: {
    flexDirection: 'row',
    backgroundColor: '#eee',
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
  },
  infoBlock: {
    flex: 1,
    justifyContent: 'center',
  },
  logo: {
    width: 60,
    height: 60,
    backgroundColor: '#ccc',
    borderRadius: 30,
    marginRight: 12,
    alignSelf: 'center',
  },
});