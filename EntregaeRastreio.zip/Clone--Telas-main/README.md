# Clone--Telas
Testar conhecimentos de programação app sobre react native, stylesheet, flexbox

Depois de clonar o repo do git, abra o terminal do VScode e rode

- npm install -g expo-cli
- cd nossoapp
- npm install
- npx expo start -c